#!/bin/bash
#Menu

echo -e "* menu      : menampilkan daftar perintah"
echo -e "* usernew   : membuat akun SSH & OpenVPN"
echo -e "* trial     : membuat akun trial"
echo -e "* hapus     : menghapus akun SSH & OpenVPN"
echo -e "* cek       : cek user login"
echo -e "* member    : cek member SSH & OpenVPN"
echo -e "* resvis    : restart service dropbear, webmin"
echo -e "              squid3, openvpn dan ssh"
echo -e "* reboot    : reboot VPS"
echo -e "* speedtest : speedtest VPS"
echo -e "* info      : menampilkan informasi sistem"
echo -e "* about     : info script auto install"
echo -e "* exit      : keluar dari Putty/Connecbot/"
echo -e "              JuiceSSH"
echo -e ""