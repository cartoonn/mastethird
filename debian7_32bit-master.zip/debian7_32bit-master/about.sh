#!/bin/bash
#About this script

clear
echo -e "Script Auto Install SSH & OpenVPN v1.0" 
echo -e ""
echo -e "For Debian 7 32 bit & 64 bit"
echo -e "For VPS with KVM and VMWare virtualization"
echo -e ""
echo -e "Original script by :"
echo -e "* Fornesia"
echo -e "* Rzengineer"
echo -e "* Fawzya"
echo -e ""
echo -e "Mod by Bustami Arifin / Abu Yazid Al-Busthami"
echo -e ""
echo -e "https://www.facebook.com/bustami.arifin.127"
echo -e "http://www.masarif.tk"
echo -e ""
