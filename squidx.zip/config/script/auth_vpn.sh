#!/bin/bash
HOST='128.199.181.105'
USER='admin'
PASS='adminjhels15'
DB='squidxvpn_database'
PORT='80'

PRE="username='$username' AND auth_vpn=md5('$password') AND confirmcode='y' AND status='live' AND is_freeze=1 AND is_active=1 AND is_ban=1 AND is_suspend=1 AND is_duration > 0 "
VIP="username='$username' AND auth_vpn=md5('$password') AND confirmcode='y' AND status='live' AND is_freeze=1 AND is_active=1 AND is_ban=1 AND is_suspend=1 AND vip_duration > 0 "
Query="SELECT username FROM user WHERE $VIP OR $PRE"
auth_vpn=`mysql -u $USER -p$PASS -D $DB -h $HOST -sN -e "$Query"`
if [ "$auth_vpn" == "$username" ]; then
	exit 0
else
	exit 1
fi