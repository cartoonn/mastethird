#!/bin/bash
tm="$(date +%s)"
dt="$(date +'%Y-%m-%d %H:%M:%S')"
timestamp="$(date +'%FT%TZ')"

HOST='128.199.181.105'
USER='admin'
PASS='adminjhels15'
DB='squidxvpn_database'
PORT='80'

##set status online to user connected
mysql -u $USER -p$PASS -D $DB -h $HOST -e "UPDATE user SET is_connected=1, login_timestamp='$tm' WHERE username='$common_name' "

bandwidth_check=`mysql -u $USER -p$PASS -D $DB -h $HOST -sN -e "SELECT username FROM bandwidth_logs WHERE username='$common_name' AND category='premium' AND status='online'"`
if [ "$bandwidth_check" == 1 ]; then
	mysql -u $USER -p$PASS -D $DB -h $HOST -e "UPDATE bandwith_logs SET server_ip='$local_1', server_port='$trusted_port', timestamp='$timestamp', ipaddress='$trusted_ip:$trusted_port', username='$common_name', time='$tm', since_connected='$time_ascii', bytes_received='$bytes_received', bytes_sent='$bytes_sent' WHERE username='$common_name' AND status='online' AND category='premium' "
else
	mysql -u $USER -p$PASS -D $DB -h $HOST -e "INSERT INTO bandwidth_logs (server_ip, server_port, timestamp, ipaddress, since_connected, username, bytes_received, bytes_sent, time_in, status, time, category) VALUES ('$local_1','$trusted_port','$timestamp','$trusted_ip:$trusted_port','$time_ascii','$common_name','$bytes_received','$bytes_sent','$dt','online','$tm','premium') "
fi
